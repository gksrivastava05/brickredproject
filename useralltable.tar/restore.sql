--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.19 (Ubuntu 10.19-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.19 (Ubuntu 10.19-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.user_eaxm DROP CONSTRAINT user_id_fkey_user_exam;
ALTER TABLE ONLY public.signup_details DROP CONSTRAINT signup_details_user_id_fkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT senior_manager_code_fkey;
ALTER TABLE ONLY public.manager DROP CONSTRAINT senior_manager_code_fkey;
ALTER TABLE ONLY public.medicine_mapping DROP CONSTRAINT medicine_mapping_medicine_id_fkey;
ALTER TABLE ONLY public.medicine_mapping DROP CONSTRAINT medicine_mapping_med_doctor_id_fkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT manager_code_fkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT lead_manager_code_fkey;
ALTER TABLE ONLY public.manager DROP CONSTRAINT lead_manager_code_fkey;
ALTER TABLE ONLY public.senior_manager DROP CONSTRAINT lead_manager_code_fkey;
ALTER TABLE ONLY public.submission_table DROP CONSTRAINT hacker_id_fky;
ALTER TABLE ONLY public.challange_table DROP CONSTRAINT hacker_id_fky;
ALTER TABLE ONLY public.user_role DROP CONSTRAINT foreign_key_user_id;
ALTER TABLE ONLY public.user_role DROP CONSTRAINT foreign_key_role_master_id;
ALTER TABLE ONLY public.user_eaxm DROP CONSTRAINT exam_master_id_fkey;
ALTER TABLE ONLY public.enrollment DROP CONSTRAINT enrollment_user_id_fkey;
ALTER TABLE ONLY public.enrollment DROP CONSTRAINT enrollment_course_id_fkey;
ALTER TABLE ONLY public.doctor_address DROP CONSTRAINT doctor_address_doctor_id_fkey;
ALTER TABLE ONLY public.challange_table DROP CONSTRAINT difficulty_id_fky;
ALTER TABLE ONLY public.employee DROP CONSTRAINT company_code_fkey;
ALTER TABLE ONLY public.manager DROP CONSTRAINT company_code_fkey;
ALTER TABLE ONLY public.senior_manager DROP CONSTRAINT company_code_fkey;
ALTER TABLE ONLY public.lead_manager DROP CONSTRAINT company_code_fkey;
ALTER TABLE ONLY public.wands DROP CONSTRAINT code_fky;
ALTER TABLE ONLY public.submission_table DROP CONSTRAINT challange_id_fky;
ALTER TABLE ONLY public.wands_property DROP CONSTRAINT wands_property_pkey;
ALTER TABLE ONLY public.user_tb DROP CONSTRAINT unique_username_constraint;
ALTER TABLE ONLY public.enrollment DROP CONSTRAINT unique_key_user_course;
ALTER TABLE ONLY public.login_user DROP CONSTRAINT unique_equip_id;
ALTER TABLE ONLY public.course DROP CONSTRAINT unique_course_name;
ALTER TABLE ONLY public.registration_form DROP CONSTRAINT unique_constraint;
ALTER TABLE ONLY public.senior_manager DROP CONSTRAINT senior_manager_code_pkey;
ALTER TABLE ONLY public.reception_app_setting DROP CONSTRAINT reception_app_setting_pkey;
ALTER TABLE ONLY public.user_role DROP CONSTRAINT primary_key_user_role;
ALTER TABLE ONLY public.role_master_tb DROP CONSTRAINT primary_key_role;
ALTER TABLE ONLY public.user_tb DROP CONSTRAINT primary_key_regis_constraint;
ALTER TABLE ONLY public.payment_details DROP CONSTRAINT primary_key_constraint;
ALTER TABLE ONLY public.medicine_definition DROP CONSTRAINT medicine_definition_pkey;
ALTER TABLE ONLY public.manager DROP CONSTRAINT manager_code_pkey;
ALTER TABLE ONLY public.login_user DROP CONSTRAINT login_pkey;
ALTER TABLE ONLY public.lead_manager DROP CONSTRAINT lead_manager_code_pkey;
ALTER TABLE ONLY public.hacker_table DROP CONSTRAINT hacker_id_pky;
ALTER TABLE ONLY public.form_details DROP CONSTRAINT form_details_pkey;
ALTER TABLE ONLY public.exam_master DROP CONSTRAINT exam_unique_key;
ALTER TABLE ONLY public.exam_master DROP CONSTRAINT exam_master_id_pkey;
ALTER TABLE ONLY public.user_eaxm DROP CONSTRAINT exam_id_pkey;
ALTER TABLE ONLY public.employee DROP CONSTRAINT employee_code_pkey;
ALTER TABLE ONLY public.doctor_details DROP CONSTRAINT doctor_details_pkey;
ALTER TABLE ONLY public.doctor_address DROP CONSTRAINT doctor_address_pkey;
ALTER TABLE ONLY public.difficulty_table DROP CONSTRAINT difficulty_table_score_key;
ALTER TABLE ONLY public.difficulty_table DROP CONSTRAINT difficulty_id_pky;
ALTER TABLE ONLY public.credentials_form DROP CONSTRAINT credentials_form_pkey;
ALTER TABLE ONLY public.course DROP CONSTRAINT course_id_primary_key;
ALTER TABLE ONLY public.company DROP CONSTRAINT company_code_pkey;
ALTER TABLE ONLY public.challange_table DROP CONSTRAINT challange_id_pky;
DROP TABLE public.wands_property;
DROP TABLE public.wands;
DROP TABLE public.venue_details;
DROP TABLE public.user_tb;
DROP TABLE public.user_role;
DROP SEQUENCE public.user_role_id;
DROP SEQUENCE public.user_id;
DROP TABLE public.user_eaxm;
DROP TABLE public.upload_file_tb;
DROP SEQUENCE public.upload_id;
DROP TABLE public.twilio_video_details;
DROP TABLE public.triangle;
DROP TABLE public.test2;
DROP TABLE public.test1;
DROP TABLE public.temp2;
DROP TABLE public.temp1;
DROP TABLE public.submission_table;
DROP TABLE public.signup_details;
DROP TABLE public.senior_manager;
DROP TABLE public.role_master_tb;
DROP SEQUENCE public.role_id;
DROP TABLE public.registration_form;
DROP SEQUENCE public.registration_id;
DROP TABLE public.reception_app_setting;
DROP TABLE public.payment_details;
DROP SEQUENCE public.payment_details_id;
DROP TABLE public.occupations_tab;
DROP TABLE public.occupations;
DROP TABLE public.medicine_mapping;
DROP TABLE public.medicine_definition;
DROP SEQUENCE public.medicine_seq;
DROP TABLE public.manager;
DROP TABLE public.mail_template;
DROP SEQUENCE public.mail_template_id;
DROP TABLE public.login_user;
DROP TABLE public.lead_manager;
DROP SEQUENCE public.id;
DROP TABLE public.hacker_table;
DROP TABLE public.form_details;
DROP SEQUENCE public.form_id;
DROP TABLE public.exam_master;
DROP SEQUENCE public.exam_master_id;
DROP SEQUENCE public.exam_id;
DROP TABLE public.enrollment;
DROP SEQUENCE public.enrollment_id;
DROP TABLE public.employee_salary;
DROP TABLE public.employee;
DROP SEQUENCE public.emp_id;
DROP TABLE public.doctor_personal_details;
DROP TABLE public.doctor_patient;
DROP TABLE public.doctor_details;
DROP TABLE public.doctor_address;
DROP SEQUENCE public.serial;
DROP TABLE public.difficulty_table;
DROP TABLE public.credentials_form;
DROP SEQUENCE public.venue_id;
DROP TABLE public.course;
DROP SEQUENCE public.course_id;
DROP TABLE public.company;
DROP TABLE public.challange_table;
DROP TABLE public.athancare_support;
DROP SEQUENCE public.support_id;
DROP TYPE public.status;
DROP EXTENSION tablefunc;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: tablefunc; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS tablefunc WITH SCHEMA public;


--
-- Name: EXTENSION tablefunc; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION tablefunc IS 'functions that manipulate whole tables, including crosstab';


--
-- Name: status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.status AS ENUM (
    '0',
    '1'
);


ALTER TYPE public.status OWNER TO postgres;

--
-- Name: support_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_id
    START WITH 10001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.support_id OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: athancare_support; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.athancare_support (
    support_id integer DEFAULT nextval('public.support_id'::regclass) NOT NULL,
    support_name character varying(50),
    support_phone_number character varying(10),
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.athancare_support OWNER TO postgres;

--
-- Name: challange_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.challange_table (
    challange_id integer NOT NULL,
    hacker_id integer,
    difficulty_id integer
);


ALTER TABLE public.challange_table OWNER TO postgres;

--
-- Name: company; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.company (
    company_code character varying(50) NOT NULL,
    founder character varying(50)
);


ALTER TABLE public.company OWNER TO postgres;

--
-- Name: course_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_id
    START WITH 1001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_id OWNER TO postgres;

--
-- Name: course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course (
    course_id integer DEFAULT nextval('public.course_id'::regclass) NOT NULL,
    course_name character varying(80) NOT NULL,
    course_description character varying(1000),
    status public.status DEFAULT '0'::public.status,
    created_date timestamp without time zone DEFAULT now(),
    updated_date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.course OWNER TO postgres;

--
-- Name: venue_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.venue_id
    START WITH 1001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.venue_id OWNER TO postgres;

--
-- Name: credentials_form; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credentials_form (
    user_id integer DEFAULT nextval('public.venue_id'::regclass) NOT NULL,
    user_name character varying(70),
    password character varying(70),
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.credentials_form OWNER TO postgres;

--
-- Name: difficulty_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.difficulty_table (
    difficulty_id integer NOT NULL,
    score integer NOT NULL
);


ALTER TABLE public.difficulty_table OWNER TO postgres;

--
-- Name: serial; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.serial
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.serial OWNER TO postgres;

--
-- Name: doctor_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_address (
    address_id bigint DEFAULT nextval('public.serial'::regclass) NOT NULL,
    doctor_id bigint,
    location character varying(60),
    district character varying(60),
    state character varying(60),
    createdtime timestamp without time zone DEFAULT now(),
    email character(50) DEFAULT 'abc@gmail.com'::bpchar,
    street character varying(50)
);


ALTER TABLE public.doctor_address OWNER TO postgres;

--
-- Name: doctor_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_details (
    doctor_id bigint DEFAULT nextval('public.serial'::regclass) NOT NULL,
    doctor_name character varying(50),
    phone_no bigint,
    cosulting_fee json,
    specialization character varying(50),
    gender character varying(10),
    createdtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.doctor_details OWNER TO postgres;

--
-- Name: doctor_patient; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_patient (
    doctor_id integer,
    patient_name character varying(50),
    patient_age integer,
    phone_number character varying(50)
);


ALTER TABLE public.doctor_patient OWNER TO postgres;

--
-- Name: doctor_personal_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.doctor_personal_details (
    doctor_id integer
);


ALTER TABLE public.doctor_personal_details OWNER TO postgres;

--
-- Name: emp_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.emp_id
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.emp_id OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_code character varying(50) NOT NULL,
    manager_code character varying(50),
    senior_manager_code character varying(50),
    lead_manager_code character varying(50),
    company_code character varying(50)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_salary; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee_salary (
    name character varying(50) NOT NULL,
    salary integer NOT NULL,
    category_id integer,
    emp_id bigint DEFAULT nextval('public.emp_id'::regclass) NOT NULL
);


ALTER TABLE public.employee_salary OWNER TO postgres;

--
-- Name: enrollment_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.enrollment_id
    START WITH 3001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enrollment_id OWNER TO postgres;

--
-- Name: enrollment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enrollment (
    enrollment_id integer DEFAULT nextval('public.enrollment_id'::regclass) NOT NULL,
    user_id integer NOT NULL,
    course_id integer NOT NULL,
    status public.status DEFAULT '0'::public.status,
    created_date timestamp without time zone DEFAULT now(),
    updated_date timestamp without time zone DEFAULT now()
);


ALTER TABLE public.enrollment OWNER TO postgres;

--
-- Name: exam_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exam_id
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_id OWNER TO postgres;

--
-- Name: exam_master_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exam_master_id
    START WITH 201
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_master_id OWNER TO postgres;

--
-- Name: exam_master; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exam_master (
    exam_master_id integer DEFAULT nextval('public.exam_master_id'::regclass) NOT NULL,
    exam character varying(50)
);


ALTER TABLE public.exam_master OWNER TO postgres;

--
-- Name: form_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.form_id
    START WITH 1000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.form_id OWNER TO postgres;

--
-- Name: form_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.form_details (
    first_name character varying(50),
    last_name character varying(50),
    age integer,
    form_id integer DEFAULT nextval('public.form_id'::regclass) NOT NULL
);


ALTER TABLE public.form_details OWNER TO postgres;

--
-- Name: hacker_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.hacker_table (
    hacker_id integer NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.hacker_table OWNER TO postgres;

--
-- Name: id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.id OWNER TO postgres;

--
-- Name: lead_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lead_manager (
    lead_manager_code character varying(50) NOT NULL,
    company_code character varying(50)
);


ALTER TABLE public.lead_manager OWNER TO postgres;

--
-- Name: login_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.login_user (
    username character varying(50) NOT NULL,
    password character varying(150),
    createdtime timestamp without time zone DEFAULT now(),
    updatedtime timestamp without time zone DEFAULT now(),
    login_id integer NOT NULL
);


ALTER TABLE public.login_user OWNER TO postgres;

--
-- Name: mail_template_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mail_template_id
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.mail_template_id OWNER TO postgres;

--
-- Name: mail_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mail_template (
    mail_template_id integer DEFAULT nextval('public.mail_template_id'::regclass) NOT NULL,
    tempate character varying(1500),
    type character varying(50)
);


ALTER TABLE public.mail_template OWNER TO postgres;

--
-- Name: manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.manager (
    manager_code character varying(50) NOT NULL,
    senior_manager_code character varying(50),
    lead_manager_code character varying(50),
    company_code character varying(50)
);


ALTER TABLE public.manager OWNER TO postgres;

--
-- Name: medicine_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.medicine_seq
    START WITH 2000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.medicine_seq OWNER TO postgres;

--
-- Name: medicine_definition; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicine_definition (
    medicine_id bigint DEFAULT nextval('public.medicine_seq'::regclass) NOT NULL,
    medicine_name character varying(100) NOT NULL,
    med_type character varying(50),
    creationtm timestamp without time zone DEFAULT now(),
    updationtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.medicine_definition OWNER TO postgres;

--
-- Name: medicine_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.medicine_mapping (
    medicine_id bigint,
    med_doctor_id bigint,
    is_favourite boolean DEFAULT false,
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.medicine_mapping OWNER TO postgres;

--
-- Name: occupations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.occupations (
    name character varying,
    occupation character varying
);


ALTER TABLE public.occupations OWNER TO postgres;

--
-- Name: occupations_tab; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.occupations_tab (
    name character varying(50),
    occupation character varying(50),
    rowid integer
);


ALTER TABLE public.occupations_tab OWNER TO postgres;

--
-- Name: payment_details_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payment_details_id
    START WITH 1000001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_details_id OWNER TO postgres;

--
-- Name: payment_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_details (
    payment_details_id bigint DEFAULT nextval('public.payment_details_id'::regclass) NOT NULL,
    amount integer DEFAULT 0,
    razorpay_order_id character varying(70),
    razorpay_payment_id character varying(70),
    razorpay_signature character varying(100),
    receipt character varying(70),
    payment_status character varying(20),
    mobile_number character varying(20),
    method character varying(20),
    createdtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_details OWNER TO postgres;

--
-- Name: reception_app_setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reception_app_setting (
    doctor_id integer NOT NULL,
    age integer DEFAULT 45,
    height integer DEFAULT 160,
    weight integer DEFAULT 55,
    express_priority integer DEFAULT '-1'::integer,
    no_show integer DEFAULT '-1'::integer,
    enable_quick_payment boolean DEFAULT false,
    enable_age_in_month_rec boolean DEFAULT false,
    scanning_mode integer DEFAULT 0,
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now(),
    doctor_name character varying(50)
);


ALTER TABLE public.reception_app_setting OWNER TO postgres;

--
-- Name: registration_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registration_id
    START WITH 1001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.registration_id OWNER TO postgres;

--
-- Name: registration_form; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registration_form (
    registration_id integer DEFAULT nextval('public.registration_id'::regclass) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    date_of_birth character varying(50),
    phone_number character varying(50),
    gender character varying(10),
    username character varying(50),
    password character varying(60),
    emai_id character varying(50)
);


ALTER TABLE public.registration_form OWNER TO postgres;

--
-- Name: role_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.role_id
    START WITH 10001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.role_id OWNER TO postgres;

--
-- Name: role_master_tb; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_master_tb (
    role_master_id integer DEFAULT nextval('public.role_id'::regclass) NOT NULL,
    role_name character varying(50) NOT NULL,
    status integer DEFAULT 0,
    createdby character varying(50),
    createdtime timestamp without time zone DEFAULT now(),
    updatedtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.role_master_tb OWNER TO postgres;

--
-- Name: senior_manager; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.senior_manager (
    senior_manager_code character varying(50) NOT NULL,
    lead_manager_code character varying(50),
    company_code character varying(50)
);


ALTER TABLE public.senior_manager OWNER TO postgres;

--
-- Name: signup_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.signup_details (
    user_id integer,
    user_fullnm character varying(70),
    user_mobile character varying(35),
    user_emailid character varying(70),
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.signup_details OWNER TO postgres;

--
-- Name: submission_table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.submission_table (
    submission_id integer,
    hacker_id integer,
    challange_id integer,
    score integer
);


ALTER TABLE public.submission_table OWNER TO postgres;

--
-- Name: temp1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp1 (
    id integer,
    name character varying(50),
    location character varying(50),
    text character varying(100)
);


ALTER TABLE public.temp1 OWNER TO postgres;

--
-- Name: temp2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.temp2 (
    id integer,
    name character varying(50),
    location character varying(50),
    text character varying(100)
);


ALTER TABLE public.temp2 OWNER TO postgres;

--
-- Name: test1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test1 (
    id integer
);


ALTER TABLE public.test1 OWNER TO postgres;

--
-- Name: test2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test2 (
    id integer
);


ALTER TABLE public.test2 OWNER TO postgres;

--
-- Name: triangle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.triangle (
    a integer,
    b integer,
    c integer
);


ALTER TABLE public.triangle OWNER TO postgres;

--
-- Name: twilio_video_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.twilio_video_details (
    doctor_id integer NOT NULL,
    patient_id character varying(50) NOT NULL,
    appointment_id character varying(50) NOT NULL,
    room_name character varying(50),
    token character varying(1000),
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.twilio_video_details OWNER TO postgres;

--
-- Name: upload_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.upload_id
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.upload_id OWNER TO postgres;

--
-- Name: upload_file_tb; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.upload_file_tb (
    upload_id integer DEFAULT nextval('public.upload_id'::regclass) NOT NULL,
    file_name character varying(80),
    createdtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.upload_file_tb OWNER TO postgres;

--
-- Name: user_eaxm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_eaxm (
    exam_id integer DEFAULT nextval('public.exam_id'::regclass) NOT NULL,
    exam_master_id integer NOT NULL,
    user_id integer NOT NULL,
    question character varying(500),
    answer character varying(50) NOT NULL,
    answer_status boolean,
    marks integer NOT NULL
);


ALTER TABLE public.user_eaxm OWNER TO postgres;

--
-- Name: user_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id
    START WITH 101
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id OWNER TO postgres;

--
-- Name: user_role_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_role_id
    START WITH 10001
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_role_id OWNER TO postgres;

--
-- Name: user_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_role (
    user_role_id integer DEFAULT nextval('public.user_role_id'::regclass) NOT NULL,
    user_id integer NOT NULL,
    role_master_id integer NOT NULL,
    status integer DEFAULT 0,
    createdby character varying(50),
    createdtime timestamp without time zone DEFAULT now(),
    updatedtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_role OWNER TO postgres;

--
-- Name: user_tb; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_tb (
    user_id integer DEFAULT nextval('public.registration_id'::regclass) NOT NULL,
    name character varying(50),
    email character varying(50),
    birthdate character varying(50),
    username character varying(50),
    password character varying(60),
    createdtm timestamp without time zone DEFAULT now(),
    updatedtime timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_tb OWNER TO postgres;

--
-- Name: venue_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venue_details (
    venue_id integer DEFAULT nextval('public.venue_id'::regclass) NOT NULL,
    venue_name character varying(70) NOT NULL,
    venue_type character varying(70) NOT NULL,
    venue_location character varying(70) NOT NULL,
    venue_start_date date NOT NULL,
    venue_end_date date NOT NULL,
    package character varying(70) NOT NULL,
    createdtm timestamp without time zone DEFAULT now(),
    updatedtm timestamp without time zone DEFAULT now()
);


ALTER TABLE public.venue_details OWNER TO postgres;

--
-- Name: wands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wands (
    id integer NOT NULL,
    code integer,
    coins_needed integer,
    power integer
);


ALTER TABLE public.wands OWNER TO postgres;

--
-- Name: wands_property; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wands_property (
    code integer NOT NULL,
    age integer,
    is_evil integer DEFAULT 0
);


ALTER TABLE public.wands_property OWNER TO postgres;

--
-- Data for Name: athancare_support; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.athancare_support (support_id, support_name, support_phone_number, createdtm, updatedtm) FROM stdin;
\.
COPY public.athancare_support (support_id, support_name, support_phone_number, createdtm, updatedtm) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: challange_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.challange_table (challange_id, hacker_id, difficulty_id) FROM stdin;
\.
COPY public.challange_table (challange_id, hacker_id, difficulty_id) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: company; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.company (company_code, founder) FROM stdin;
\.
COPY public.company (company_code, founder) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course (course_id, course_name, course_description, status, created_date, updated_date) FROM stdin;
\.
COPY public.course (course_id, course_name, course_description, status, created_date, updated_date) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: credentials_form; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credentials_form (user_id, user_name, password, createdtm, updatedtm) FROM stdin;
\.
COPY public.credentials_form (user_id, user_name, password, createdtm, updatedtm) FROM '$$PATH$$/3306.dat';

--
-- Data for Name: difficulty_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.difficulty_table (difficulty_id, score) FROM stdin;
\.
COPY public.difficulty_table (difficulty_id, score) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: doctor_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_address (address_id, doctor_id, location, district, state, createdtime, email, street) FROM stdin;
\.
COPY public.doctor_address (address_id, doctor_id, location, district, state, createdtime, email, street) FROM '$$PATH$$/3299.dat';

--
-- Data for Name: doctor_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_details (doctor_id, doctor_name, phone_no, cosulting_fee, specialization, gender, createdtime) FROM stdin;
\.
COPY public.doctor_details (doctor_id, doctor_name, phone_no, cosulting_fee, specialization, gender, createdtime) FROM '$$PATH$$/3298.dat';

--
-- Data for Name: doctor_patient; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_patient (doctor_id, patient_name, patient_age, phone_number) FROM stdin;
\.
COPY public.doctor_patient (doctor_id, patient_name, patient_age, phone_number) FROM '$$PATH$$/3311.dat';

--
-- Data for Name: doctor_personal_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.doctor_personal_details (doctor_id) FROM stdin;
\.
COPY public.doctor_personal_details (doctor_id) FROM '$$PATH$$/3314.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_code, manager_code, senior_manager_code, lead_manager_code, company_code) FROM stdin;
\.
COPY public.employee (employee_code, manager_code, senior_manager_code, lead_manager_code, company_code) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: employee_salary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee_salary (name, salary, category_id, emp_id) FROM stdin;
\.
COPY public.employee_salary (name, salary, category_id, emp_id) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: enrollment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enrollment (enrollment_id, user_id, course_id, status, created_date, updated_date) FROM stdin;
\.
COPY public.enrollment (enrollment_id, user_id, course_id, status, created_date, updated_date) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: exam_master; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exam_master (exam_master_id, exam) FROM stdin;
\.
COPY public.exam_master (exam_master_id, exam) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: form_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.form_details (first_name, last_name, age, form_id) FROM stdin;
\.
COPY public.form_details (first_name, last_name, age, form_id) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: hacker_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.hacker_table (hacker_id, name) FROM stdin;
\.
COPY public.hacker_table (hacker_id, name) FROM '$$PATH$$/3321.dat';

--
-- Data for Name: lead_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lead_manager (lead_manager_code, company_code) FROM stdin;
\.
COPY public.lead_manager (lead_manager_code, company_code) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: login_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.login_user (username, password, createdtime, updatedtime, login_id) FROM stdin;
\.
COPY public.login_user (username, password, createdtime, updatedtime, login_id) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: mail_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mail_template (mail_template_id, tempate, type) FROM stdin;
\.
COPY public.mail_template (mail_template_id, tempate, type) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.manager (manager_code, senior_manager_code, lead_manager_code, company_code) FROM stdin;
\.
COPY public.manager (manager_code, senior_manager_code, lead_manager_code, company_code) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: medicine_definition; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicine_definition (medicine_id, medicine_name, med_type, creationtm, updationtm) FROM stdin;
\.
COPY public.medicine_definition (medicine_id, medicine_name, med_type, creationtm, updationtm) FROM '$$PATH$$/3301.dat';

--
-- Data for Name: medicine_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.medicine_mapping (medicine_id, med_doctor_id, is_favourite, createdtm, updatedtm) FROM stdin;
\.
COPY public.medicine_mapping (medicine_id, med_doctor_id, is_favourite, createdtm, updatedtm) FROM '$$PATH$$/3302.dat';

--
-- Data for Name: occupations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.occupations (name, occupation) FROM stdin;
\.
COPY public.occupations (name, occupation) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: occupations_tab; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.occupations_tab (name, occupation, rowid) FROM stdin;
\.
COPY public.occupations_tab (name, occupation, rowid) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: payment_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_details (payment_details_id, amount, razorpay_order_id, razorpay_payment_id, razorpay_signature, receipt, payment_status, mobile_number, method, createdtime) FROM stdin;
\.
COPY public.payment_details (payment_details_id, amount, razorpay_order_id, razorpay_payment_id, razorpay_signature, receipt, payment_status, mobile_number, method, createdtime) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: reception_app_setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reception_app_setting (doctor_id, age, height, weight, express_priority, no_show, enable_quick_payment, enable_age_in_month_rec, scanning_mode, createdtm, updatedtm, doctor_name) FROM stdin;
\.
COPY public.reception_app_setting (doctor_id, age, height, weight, express_priority, no_show, enable_quick_payment, enable_age_in_month_rec, scanning_mode, createdtm, updatedtm, doctor_name) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: registration_form; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registration_form (registration_id, first_name, last_name, date_of_birth, phone_number, gender, username, password, emai_id) FROM stdin;
\.
COPY public.registration_form (registration_id, first_name, last_name, date_of_birth, phone_number, gender, username, password, emai_id) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: role_master_tb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_master_tb (role_master_id, role_name, status, createdby, createdtime, updatedtime) FROM stdin;
\.
COPY public.role_master_tb (role_master_id, role_name, status, createdby, createdtime, updatedtime) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: senior_manager; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.senior_manager (senior_manager_code, lead_manager_code, company_code) FROM stdin;
\.
COPY public.senior_manager (senior_manager_code, lead_manager_code, company_code) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: signup_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.signup_details (user_id, user_fullnm, user_mobile, user_emailid, createdtm, updatedtm) FROM stdin;
\.
COPY public.signup_details (user_id, user_fullnm, user_mobile, user_emailid, createdtm, updatedtm) FROM '$$PATH$$/3307.dat';

--
-- Data for Name: submission_table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.submission_table (submission_id, hacker_id, challange_id, score) FROM stdin;
\.
COPY public.submission_table (submission_id, hacker_id, challange_id, score) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: temp1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp1 (id, name, location, text) FROM stdin;
\.
COPY public.temp1 (id, name, location, text) FROM '$$PATH$$/3308.dat';

--
-- Data for Name: temp2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.temp2 (id, name, location, text) FROM stdin;
\.
COPY public.temp2 (id, name, location, text) FROM '$$PATH$$/3309.dat';

--
-- Data for Name: test1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test1 (id) FROM stdin;
\.
COPY public.test1 (id) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: test2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test2 (id) FROM stdin;
\.
COPY public.test2 (id) FROM '$$PATH$$/3313.dat';

--
-- Data for Name: triangle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.triangle (a, b, c) FROM stdin;
\.
COPY public.triangle (a, b, c) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: twilio_video_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.twilio_video_details (doctor_id, patient_id, appointment_id, room_name, token, createdtm, updatedtm) FROM stdin;
\.
COPY public.twilio_video_details (doctor_id, patient_id, appointment_id, room_name, token, createdtm, updatedtm) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: upload_file_tb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.upload_file_tb (upload_id, file_name, createdtime) FROM stdin;
\.
COPY public.upload_file_tb (upload_id, file_name, createdtime) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: user_eaxm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_eaxm (exam_id, exam_master_id, user_id, question, answer, answer_status, marks) FROM stdin;
\.
COPY public.user_eaxm (exam_id, exam_master_id, user_id, question, answer, answer_status, marks) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_role (user_role_id, user_id, role_master_id, status, createdby, createdtime, updatedtime) FROM stdin;
\.
COPY public.user_role (user_role_id, user_id, role_master_id, status, createdby, createdtime, updatedtime) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: user_tb; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_tb (user_id, name, email, birthdate, username, password, createdtm, updatedtime) FROM stdin;
\.
COPY public.user_tb (user_id, name, email, birthdate, username, password, createdtm, updatedtime) FROM '$$PATH$$/3342.dat';

--
-- Data for Name: venue_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venue_details (venue_id, venue_name, venue_type, venue_location, venue_start_date, venue_end_date, package, createdtm, updatedtm) FROM stdin;
\.
COPY public.venue_details (venue_id, venue_name, venue_type, venue_location, venue_start_date, venue_end_date, package, createdtm, updatedtm) FROM '$$PATH$$/3304.dat';

--
-- Data for Name: wands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wands (id, code, coins_needed, power) FROM stdin;
\.
COPY public.wands (id, code, coins_needed, power) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: wands_property; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wands_property (code, age, is_evil) FROM stdin;
\.
COPY public.wands_property (code, age, is_evil) FROM '$$PATH$$/3327.dat';

--
-- Name: course_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_id', 1008, true);


--
-- Name: emp_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.emp_id', 108, true);


--
-- Name: enrollment_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.enrollment_id', 3009, true);


--
-- Name: exam_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exam_id', 131, true);


--
-- Name: exam_master_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exam_master_id', 203, true);


--
-- Name: form_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.form_id', 1005, true);


--
-- Name: id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.id', 3, true);


--
-- Name: mail_template_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mail_template_id', 115, true);


--
-- Name: medicine_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.medicine_seq', 2005, true);


--
-- Name: payment_details_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payment_details_id', 1000014, true);


--
-- Name: registration_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registration_id', 1018, true);


--
-- Name: role_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.role_id', 10010, true);


--
-- Name: serial; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.serial', 1036, true);


--
-- Name: support_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_id', 10001, true);


--
-- Name: upload_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.upload_id', 111, true);


--
-- Name: user_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id', 101, false);


--
-- Name: user_role_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_role_id', 10010, true);


--
-- Name: venue_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.venue_id', 1005, true);


--
-- Name: challange_table challange_id_pky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challange_table
    ADD CONSTRAINT challange_id_pky PRIMARY KEY (challange_id);


--
-- Name: company company_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.company
    ADD CONSTRAINT company_code_pkey PRIMARY KEY (company_code);


--
-- Name: course course_id_primary_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_id_primary_key PRIMARY KEY (course_id);


--
-- Name: credentials_form credentials_form_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credentials_form
    ADD CONSTRAINT credentials_form_pkey PRIMARY KEY (user_id);


--
-- Name: difficulty_table difficulty_id_pky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.difficulty_table
    ADD CONSTRAINT difficulty_id_pky PRIMARY KEY (difficulty_id);


--
-- Name: difficulty_table difficulty_table_score_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.difficulty_table
    ADD CONSTRAINT difficulty_table_score_key UNIQUE (score);


--
-- Name: doctor_address doctor_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_address
    ADD CONSTRAINT doctor_address_pkey PRIMARY KEY (address_id);


--
-- Name: doctor_details doctor_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_details
    ADD CONSTRAINT doctor_details_pkey PRIMARY KEY (doctor_id);


--
-- Name: employee employee_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_code_pkey PRIMARY KEY (employee_code);


--
-- Name: user_eaxm exam_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_eaxm
    ADD CONSTRAINT exam_id_pkey PRIMARY KEY (exam_id);


--
-- Name: exam_master exam_master_id_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_master
    ADD CONSTRAINT exam_master_id_pkey PRIMARY KEY (exam_master_id);


--
-- Name: exam_master exam_unique_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exam_master
    ADD CONSTRAINT exam_unique_key UNIQUE (exam);


--
-- Name: form_details form_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.form_details
    ADD CONSTRAINT form_details_pkey PRIMARY KEY (form_id);


--
-- Name: hacker_table hacker_id_pky; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.hacker_table
    ADD CONSTRAINT hacker_id_pky PRIMARY KEY (hacker_id);


--
-- Name: lead_manager lead_manager_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_manager
    ADD CONSTRAINT lead_manager_code_pkey PRIMARY KEY (lead_manager_code);


--
-- Name: login_user login_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_user
    ADD CONSTRAINT login_pkey PRIMARY KEY (login_id);


--
-- Name: manager manager_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT manager_code_pkey PRIMARY KEY (manager_code);


--
-- Name: medicine_definition medicine_definition_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicine_definition
    ADD CONSTRAINT medicine_definition_pkey PRIMARY KEY (medicine_id);


--
-- Name: payment_details primary_key_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_details
    ADD CONSTRAINT primary_key_constraint PRIMARY KEY (payment_details_id);


--
-- Name: user_tb primary_key_regis_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tb
    ADD CONSTRAINT primary_key_regis_constraint PRIMARY KEY (user_id);


--
-- Name: role_master_tb primary_key_role; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_master_tb
    ADD CONSTRAINT primary_key_role PRIMARY KEY (role_master_id);


--
-- Name: user_role primary_key_user_role; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT primary_key_user_role PRIMARY KEY (user_role_id);


--
-- Name: reception_app_setting reception_app_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reception_app_setting
    ADD CONSTRAINT reception_app_setting_pkey PRIMARY KEY (doctor_id);


--
-- Name: senior_manager senior_manager_code_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.senior_manager
    ADD CONSTRAINT senior_manager_code_pkey PRIMARY KEY (senior_manager_code);


--
-- Name: registration_form unique_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registration_form
    ADD CONSTRAINT unique_constraint UNIQUE (username);


--
-- Name: course unique_course_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT unique_course_name UNIQUE (course_name);


--
-- Name: login_user unique_equip_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.login_user
    ADD CONSTRAINT unique_equip_id UNIQUE (username);


--
-- Name: enrollment unique_key_user_course; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT unique_key_user_course UNIQUE (user_id, course_id);


--
-- Name: user_tb unique_username_constraint; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_tb
    ADD CONSTRAINT unique_username_constraint UNIQUE (username);


--
-- Name: wands_property wands_property_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wands_property
    ADD CONSTRAINT wands_property_pkey PRIMARY KEY (code);


--
-- Name: submission_table challange_id_fky; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission_table
    ADD CONSTRAINT challange_id_fky FOREIGN KEY (challange_id) REFERENCES public.challange_table(challange_id);


--
-- Name: wands code_fky; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wands
    ADD CONSTRAINT code_fky FOREIGN KEY (code) REFERENCES public.wands_property(code);


--
-- Name: lead_manager company_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lead_manager
    ADD CONSTRAINT company_code_fkey FOREIGN KEY (company_code) REFERENCES public.company(company_code);


--
-- Name: senior_manager company_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.senior_manager
    ADD CONSTRAINT company_code_fkey FOREIGN KEY (company_code) REFERENCES public.company(company_code);


--
-- Name: manager company_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT company_code_fkey FOREIGN KEY (company_code) REFERENCES public.company(company_code);


--
-- Name: employee company_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT company_code_fkey FOREIGN KEY (company_code) REFERENCES public.company(company_code);


--
-- Name: challange_table difficulty_id_fky; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challange_table
    ADD CONSTRAINT difficulty_id_fky FOREIGN KEY (difficulty_id) REFERENCES public.difficulty_table(difficulty_id);


--
-- Name: doctor_address doctor_address_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.doctor_address
    ADD CONSTRAINT doctor_address_doctor_id_fkey FOREIGN KEY (doctor_id) REFERENCES public.doctor_details(doctor_id);


--
-- Name: enrollment enrollment_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT enrollment_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: enrollment enrollment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enrollment
    ADD CONSTRAINT enrollment_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.user_tb(user_id);


--
-- Name: user_eaxm exam_master_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_eaxm
    ADD CONSTRAINT exam_master_id_fkey FOREIGN KEY (exam_master_id) REFERENCES public.exam_master(exam_master_id);


--
-- Name: user_role foreign_key_role_master_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT foreign_key_role_master_id FOREIGN KEY (role_master_id) REFERENCES public.role_master_tb(role_master_id);


--
-- Name: user_role foreign_key_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT foreign_key_user_id FOREIGN KEY (user_id) REFERENCES public.user_tb(user_id);


--
-- Name: challange_table hacker_id_fky; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.challange_table
    ADD CONSTRAINT hacker_id_fky FOREIGN KEY (hacker_id) REFERENCES public.hacker_table(hacker_id);


--
-- Name: submission_table hacker_id_fky; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.submission_table
    ADD CONSTRAINT hacker_id_fky FOREIGN KEY (hacker_id) REFERENCES public.hacker_table(hacker_id);


--
-- Name: senior_manager lead_manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.senior_manager
    ADD CONSTRAINT lead_manager_code_fkey FOREIGN KEY (lead_manager_code) REFERENCES public.lead_manager(lead_manager_code);


--
-- Name: manager lead_manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT lead_manager_code_fkey FOREIGN KEY (lead_manager_code) REFERENCES public.lead_manager(lead_manager_code);


--
-- Name: employee lead_manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT lead_manager_code_fkey FOREIGN KEY (lead_manager_code) REFERENCES public.lead_manager(lead_manager_code);


--
-- Name: employee manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT manager_code_fkey FOREIGN KEY (manager_code) REFERENCES public.manager(manager_code);


--
-- Name: medicine_mapping medicine_mapping_med_doctor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicine_mapping
    ADD CONSTRAINT medicine_mapping_med_doctor_id_fkey FOREIGN KEY (med_doctor_id) REFERENCES public.doctor_details(doctor_id);


--
-- Name: medicine_mapping medicine_mapping_medicine_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.medicine_mapping
    ADD CONSTRAINT medicine_mapping_medicine_id_fkey FOREIGN KEY (medicine_id) REFERENCES public.medicine_definition(medicine_id);


--
-- Name: manager senior_manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.manager
    ADD CONSTRAINT senior_manager_code_fkey FOREIGN KEY (senior_manager_code) REFERENCES public.senior_manager(senior_manager_code);


--
-- Name: employee senior_manager_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT senior_manager_code_fkey FOREIGN KEY (senior_manager_code) REFERENCES public.senior_manager(senior_manager_code);


--
-- Name: signup_details signup_details_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.signup_details
    ADD CONSTRAINT signup_details_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.credentials_form(user_id);


--
-- Name: user_eaxm user_id_fkey_user_exam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_eaxm
    ADD CONSTRAINT user_id_fkey_user_exam FOREIGN KEY (user_id) REFERENCES public.user_tb(user_id);


--
-- PostgreSQL database dump complete
--

